#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
🌍 MrLiou 粒子立體地球儀記憶系統 (Particle Globe Memory System)
=================================================================
融合版 v2.0 - 整合所有模組：
  - Memory Quick Mount (MQM) - 記憶快照掛載
  - Ingest Universal Map - KML/KMZ/GeoJSON 匯入
  - Particle Compressor - 粒子化壓縮
  - Analyst Guardian - 分析師守護者（內容分析）
  - GPS Binding - 真實座標綁定

核心理念：
  「怎麼過去，就怎麼回來」
  「地球在，記憶就在」
  「一顆地球儀 = 一個人的一生軌跡」

Author: MR.liou × Claude
Date: 2026-01-04
"""

import os
import sys
import json
import time
import argparse
import hashlib
import re
from pathlib import Path
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from collections import Counter
from zipfile import ZipFile
import xml.etree.ElementTree as ET

try:
    import yaml
except ImportError:
    yaml = None


# ============================================================================
# 第一部分：基礎工具
# ============================================================================

def ulid() -> str:
    """生成 ULID 風格的唯一 ID"""
    ts = int(time.time() * 1000)
    rand = hashlib.sha1(f"{time.time_ns()}_{os.getpid()}".encode()).hexdigest()[:16]
    return f"{ts:013d}{rand}"[:26]


def safe_filename(name: str) -> str:
    """轉換為安全的檔案名"""
    return re.sub(r"[^a-zA-Z0-9_.\u4e00-\u9fff-]+", "_", name).strip("_")


# ============================================================================
# 第二部分：粒子壓縮器 (Particle Compressor)
# ============================================================================

class ParticleCompressor:
    """基礎粒子壓縮器 - 將資訊轉換為粒子序列"""
    
    def __init__(self):
        self.code_map = {
            "時間": "000", "主體": "001", "夥伴": "010", 
            "行動": "011", "項目": "100", "座標": "101",
            "內容": "110", "標籤": "111"
        }
        self.reverse_map = {v: k for k, v in self.code_map.items()}
    
    def compress(self, info: Dict[str, Any]) -> Dict[str, Any]:
        """壓縮資訊為粒子封包"""
        seq, mapping = [], {}
        for k, v in info.items():
            code = self.code_map.get(k, "999")
            seq.append(code)
            mapping[code] = v
        return {"粒子序列": "-".join(seq), "對照表": mapping}
    
    def decompress(self, packet: Dict[str, Any]) -> Dict[str, Any]:
        """還原粒子封包為原始資訊"""
        seq = packet.get("粒子序列", "").split("-")
        mapping = packet.get("對照表", {})
        out = {}
        for code in seq:
            key = self.reverse_map.get(code, "未知")
            out[key] = mapping.get(code, "")
        return out


class AdvancedParticleCompressor:
    """進階粒子壓縮器 - 支援巢狀結構的 δP₀ 微單元壓縮"""
    
    def __init__(self):
        self.code_map = {
            "主體": "A01", "任務": "B01", "子任務": "C01",
            "負責人": "D01", "狀態": "E01", "合作": "F01",
            "座標": "G01", "時間": "H01", "內容": "I01",
            "標籤": "J01", "關聯": "K01", "元資料": "L01"
        }
        self.reverse_map = {v: k for k, v in self.code_map.items()}
    
    def _helper_compress(self, obj, seq, mapping):
        if isinstance(obj, dict):
            for k, v in obj.items():
                code = self.code_map.get(k, "ZZZ")
                seq.append(code)
                if isinstance(v, (dict, list)):
                    mapping[code] = self._helper_compress(v, seq, {} if isinstance(v, dict) else [])
                else:
                    mapping[code] = v
            return mapping
        elif isinstance(obj, list):
            arr = []
            for item in obj:
                if isinstance(item, (dict, list)):
                    arr.append(self._helper_compress(item, seq, {} if isinstance(item, dict) else []))
                else:
                    arr.append(item)
            return arr
        return mapping
    
    def compress(self, info: Dict[str, Any]) -> Dict[str, Any]:
        """壓縮（支援巢狀結構）"""
        seq, mapping = [], {}
        compressed_map = self._helper_compress(info, seq, mapping)
        return {"粒子序列": "-".join(seq), "對照表": compressed_map}
    
    def _helper_decompress(self, mapping):
        res = {}
        if isinstance(mapping, dict):
            for code, v in mapping.items():
                key = self.reverse_map.get(code, code)
                if isinstance(v, dict):
                    res[key] = self._helper_decompress(v)
                elif isinstance(v, list):
                    res[key] = [self._helper_decompress(x) if isinstance(x, dict) else x for x in v]
                else:
                    res[key] = v
        else:
            return mapping
        return res
    
    def decompress(self, packet: Dict[str, Any]) -> Dict[str, Any]:
        """還原（支援巢狀結構）"""
        return self._helper_decompress(packet.get("對照表", {}))


# ============================================================================
# 第三部分：分析師守護者 (Analyst Guardian)
# ============================================================================

class AnalystGuardian:
    """
    🧭 分析師守護者 - 內容分析與知識萃取
    
    核心能力：
    1. 看懂本質 - 識別深層規律
    2. 拆解結構 - 分解成基本單位
    3. 識別模式 - 看出相同模式
    4. 組合重構 - 重新組合
    
    工作流程 (ROAO)：
    接收 → 觀察 → 分析 → 輸出
    """
    
    # 停用詞
    STOPWORDS = {
        'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been',
        'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will',
        'would', 'could', 'should', 'may', 'might', 'must', 'shall',
        'can', 'need', 'dare', 'ought', 'used', 'to', 'of', 'in',
        'for', 'on', 'with', 'at', 'by', 'from', 'as', 'into',
        'through', 'during', 'before', 'after', 'above', 'below',
        'between', 'under', 'again', 'further', 'then', 'once',
        '的', '了', '是', '在', '我', '你', '他', '她', '它',
        '這', '那', '有', '個', '們', '和', '與', '或', '但',
        '如果', '因為', '所以', '雖然', '但是', '而且', '不過'
    }
    
    def __init__(self):
        self.compressor = AdvancedParticleCompressor()
    
    # ==================== ROAO 流程 ====================
    
    def receive(self, content: str) -> Dict[str, Any]:
        """接收 - 完整接收原始輸入"""
        return {
            "raw_content": content,
            "length": len(content),
            "received_at": datetime.now().isoformat()
        }
    
    def observe(self, received: Dict[str, Any]) -> Dict[str, Any]:
        """觀察 - 識別結構與模式"""
        content = received["raw_content"]
        
        # 識別內容類型
        content_type = self._identify_content_type(content)
        
        # 識別語言
        language = self._identify_language(content)
        
        # 識別結構特徵
        structure = self._identify_structure(content)
        
        return {
            "content_type": content_type,
            "language": language,
            "structure": structure,
            "observation_at": datetime.now().isoformat()
        }
    
    def analyze(self, content: str, observation: Dict[str, Any]) -> Dict[str, Any]:
        """分析 - 拆解成粒子"""
        
        # 提取關鍵詞
        keywords = self.extract_keywords(content, top_n=10)
        
        # 提取核心概念
        concepts = self._extract_concepts(content)
        
        # 識別因果關係
        causal_relations = self._extract_causal_relations(content)
        
        # 注意力分析（識別重點）
        attention = self._analyze_attention(content)
        
        # 情感傾向
        sentiment = self._analyze_sentiment(content)
        
        return {
            "keywords": keywords,
            "concepts": concepts,
            "causal_relations": causal_relations,
            "attention": attention,
            "sentiment": sentiment,
            "analysis_at": datetime.now().isoformat()
        }
    
    def output(self, content: str, observation: Dict, analysis: Dict) -> Dict[str, Any]:
        """輸出 - 重新組合為結構化結果"""
        
        # 生成摘要
        summary = self._generate_summary(content, analysis)
        
        # 生成標籤
        tags = self._generate_tags(analysis)
        
        # 組合最終結果
        result = {
            "summary": summary,
            "tags": tags,
            "content_type": observation["content_type"],
            "language": observation["language"],
            "keywords": analysis["keywords"],
            "concepts": analysis["concepts"],
            "sentiment": analysis["sentiment"],
            "processed_at": datetime.now().isoformat()
        }
        
        return result
    
    def process(self, content: str) -> Dict[str, Any]:
        """完整 ROAO 流程"""
        received = self.receive(content)
        observation = self.observe(received)
        analysis = self.analyze(content, observation)
        output = self.output(content, observation, analysis)
        return output
    
    # ==================== 分析工具 ====================
    
    def extract_keywords(self, text: str, top_n: int = 10) -> List[str]:
        """提取關鍵詞"""
        # 英文詞
        words = re.findall(r'\b[a-zA-Z]{3,}\b', text.lower())
        # 中文詞（2-4字）
        chinese = re.findall(r'[\u4e00-\u9fff]{2,4}', text)
        
        all_words = words + chinese
        filtered = [w for w in all_words if w.lower() not in self.STOPWORDS]
        
        counter = Counter(filtered)
        return [word for word, _ in counter.most_common(top_n)]
    
    def _identify_content_type(self, content: str) -> str:
        """識別內容類型"""
        if re.search(r'```|def |class |import |function', content):
            return "code"
        elif re.search(r'^\s*[-*]\s+', content, re.MULTILINE):
            return "list"
        elif re.search(r'^\s*\d+\.\s+', content, re.MULTILINE):
            return "numbered_list"
        elif re.search(r'https?://|www\.', content):
            return "link_rich"
        elif len(content) < 100:
            return "short_text"
        elif len(content) > 1000:
            return "long_text"
        else:
            return "normal_text"
    
    def _identify_language(self, content: str) -> str:
        """識別語言"""
        chinese_chars = len(re.findall(r'[\u4e00-\u9fff]', content))
        english_words = len(re.findall(r'\b[a-zA-Z]+\b', content))
        
        if chinese_chars > english_words * 2:
            return "zh"
        elif english_words > chinese_chars * 2:
            return "en"
        else:
            return "mixed"
    
    def _identify_structure(self, content: str) -> Dict[str, Any]:
        """識別結構特徵"""
        lines = content.split('\n')
        return {
            "line_count": len(lines),
            "has_headers": bool(re.search(r'^#+\s+', content, re.MULTILINE)),
            "has_lists": bool(re.search(r'^\s*[-*]\s+', content, re.MULTILINE)),
            "has_code": bool(re.search(r'```', content)),
            "paragraph_count": len([l for l in lines if l.strip()])
        }
    
    def _extract_concepts(self, text: str) -> List[str]:
        """提取核心概念"""
        # 英文專有名詞（大寫開頭）
        proper_nouns = re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', text)
        
        # 中文專有名詞
        chinese_concepts = re.findall(
            r'[\u4e00-\u9fff]{2,6}(?:系統|理論|模型|機制|方法|架構|人格|模組|算法|引擎)',
            text
        )
        
        # 技術術語
        tech_terms = re.findall(
            r'\b(?:API|SDK|GPS|KML|JSON|YAML|AI|ML|3D|VR|AR)\b',
            text, re.IGNORECASE
        )
        
        all_concepts = list(set(proper_nouns + chinese_concepts + tech_terms))
        return all_concepts[:20]
    
    def _extract_causal_relations(self, text: str) -> List[Dict[str, str]]:
        """提取因果關係"""
        relations = []
        
        patterns = [
            (r'因為(.{5,50})所以(.{5,50})', 'because-therefore'),
            (r'由於(.{5,50})因此(.{5,50})', 'due-to-hence'),
            (r'(.{5,50})導致(.{5,50})', 'leads-to'),
            (r'如果(.{5,50})那麼(.{5,50})', 'if-then'),
            (r'(.{5,50})的結果是(.{5,50})', 'result-is'),
        ]
        
        for pattern, rel_type in patterns:
            matches = re.findall(pattern, text)
            for match in matches:
                relations.append({
                    "type": rel_type,
                    "cause": match[0].strip(),
                    "effect": match[1].strip()
                })
        
        return relations[:10]
    
    def _analyze_attention(self, text: str) -> Dict[str, Any]:
        """注意力分析 - 識別重點區域"""
        # 找出強調的內容
        bold_content = re.findall(r'\*\*(.+?)\*\*', text)
        heading_content = re.findall(r'^#+\s+(.+)$', text, re.MULTILINE)
        
        # 找出問句
        questions = re.findall(r'[^。！？\n]*[？?]', text)
        
        return {
            "emphasized": bold_content[:5],
            "headings": heading_content[:5],
            "questions": questions[:5]
        }
    
    def _analyze_sentiment(self, text: str) -> str:
        """簡易情感分析"""
        positive_words = ['好', '棒', '讚', '優', '佳', '成功', '完成', 'good', 'great', 'excellent', 'success']
        negative_words = ['差', '壞', '糟', '失敗', '錯誤', 'bad', 'fail', 'error', 'wrong']
        
        pos_count = sum(1 for w in positive_words if w in text.lower())
        neg_count = sum(1 for w in negative_words if w in text.lower())
        
        if pos_count > neg_count + 2:
            return "positive"
        elif neg_count > pos_count + 2:
            return "negative"
        else:
            return "neutral"
    
    def _generate_summary(self, content: str, analysis: Dict) -> str:
        """生成摘要"""
        keywords = analysis["keywords"][:5]
        concepts = analysis["concepts"][:3]
        
        if keywords:
            keyword_str = "、".join(keywords)
            summary = f"主要討論：{keyword_str}"
            if concepts:
                concept_str = "、".join(concepts)
                summary += f"。涉及概念：{concept_str}"
            return summary
        else:
            return content[:100] + "..." if len(content) > 100 else content
    
    def _generate_tags(self, analysis: Dict) -> List[str]:
        """生成標籤"""
        tags = []
        
        # 從關鍵詞生成
        tags.extend(analysis["keywords"][:3])
        
        # 從概念生成
        tags.extend(analysis["concepts"][:2])
        
        # 情感標籤
        if analysis["sentiment"] != "neutral":
            tags.append(analysis["sentiment"])
        
        return list(set(tags))[:8]


# ============================================================================
# 第四部分：KML/KMZ 處理器
# ============================================================================

class KMLProcessor:
    """KML/KMZ/GeoJSON 處理器 - 匯入匯出地理資料"""
    
    EARTH_WORDS = ["earth", "地球"]
    MARS_WORDS = ["mars", "火星"]
    MOON_WORDS = ["moon", "月球", "月亮"]
    
    @staticmethod
    def infer_body(text: str) -> str:
        """推斷天體類型"""
        t = text.lower()
        if any(w in t for w in KMLProcessor.MARS_WORDS):
            return "mars"
        if any(w in t for w in KMLProcessor.MOON_WORDS):
            return "moon"
        return "earth"
    
    @staticmethod
    def load_kml_from_kmz(path: Path) -> str:
        """從 KMZ 讀取 KML"""
        with ZipFile(path, "r") as z:
            kml_name = None
            for name in z.namelist():
                if name.endswith("doc.kml"):
                    kml_name = name
                    break
            if kml_name is None:
                for name in z.namelist():
                    if name.lower().endswith(".kml"):
                        kml_name = name
                        break
            if kml_name is None:
                raise RuntimeError("No KML found inside KMZ")
            return z.read(kml_name).decode("utf-8", errors="ignore")
    
    @staticmethod
    def parse_kml(kml_text: str, source: str, body_hint: Optional[str] = None) -> List[Dict]:
        """解析 KML 文字"""
        ns = {"kml": "http://www.opengis.net/kml/2.2"}
        
        try:
            root = ET.fromstring(kml_text)
        except ET.ParseError:
            kml_text = kml_text.replace("\ufeff", "")
            root = ET.fromstring(kml_text)
        
        doc_name = ""
        for el in root.findall(".//kml:Document/kml:name", ns):
            if el.text:
                doc_name = el.text
        
        body = body_hint or KMLProcessor.infer_body(doc_name)
        nodes = []
        
        for pm in root.findall(".//kml:Placemark", ns):
            name_el = pm.find("kml:name", ns)
            name = name_el.text if name_el is not None and name_el.text else "Untitled"
            
            desc_el = pm.find("kml:description", ns)
            desc = desc_el.text if desc_el is not None else ""
            
            # 時間
            ts = pm.find("kml:TimeStamp/kml:when", ns)
            when = ts.text if ts is not None else None
            
            # 座標
            coord_el = pm.find(".//kml:Point/kml:coordinates", ns)
            lon, lat, alt = None, None, 0
            if coord_el is not None and coord_el.text:
                parts = coord_el.text.strip().split(",")
                if len(parts) >= 2:
                    lon = float(parts[0].strip())
                    lat = float(parts[1].strip())
                    alt = float(parts[2].strip()) if len(parts) >= 3 and parts[2].strip() else 0.0
            
            # 生成 ID
            safe = safe_filename(name)
            datepart = (when or "").replace(":", "").replace("-", "")[:8] or datetime.utcnow().strftime("%Y%m%d")
            node_id = f"{body.capitalize()}.{safe}.{datepart}"
            
            node = {
                "id": node_id,
                "body": body,
                "title": name,
                "coords": {"lon": lon, "lat": lat, "alt": alt},
                "time": when,
                "links": {"source": Path(source).name},
                "tags": ["import", "kml"]
            }
            if desc:
                node["meta"] = {"description": desc}
            nodes.append(node)
        
        return nodes
    
    @staticmethod
    def generate_kml(particles: List[Dict], title: str = "粒子地球儀記錄") -> str:
        """生成 KML 檔案內容"""
        kml = f'''<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
<Document>
    <name>{title}</name>
    <description>由粒子立體地球儀記憶系統生成</description>
'''
        
        for p in particles:
            coords = p.get("coords", {})
            lon = coords.get("lon", 0)
            lat = coords.get("lat", 0)
            alt = coords.get("alt", 0)
            
            name = p.get("title", p.get("name", "未命名"))
            desc = p.get("summary", p.get("meta", {}).get("description", ""))
            tags = ", ".join(p.get("tags", []))
            
            kml += f'''
    <Placemark>
        <name>{name}</name>
        <description><![CDATA[{desc}<br/>標籤: {tags}]]></description>
        <Point>
            <coordinates>{lon},{lat},{alt}</coordinates>
        </Point>
    </Placemark>
'''
        
        kml += '''
</Document>
</kml>'''
        
        return kml


# ============================================================================
# 第五部分：粒子地球儀核心系統
# ============================================================================

class ParticleGlobeMemorySystem:
    """
    🌍 粒子立體地球儀記憶系統 - 核心類別
    
    整合所有模組：
    - 粒子壓縮
    - 分析師守護者
    - KML 處理
    - 記憶掛載
    
    核心概念：
    - 一顆地球儀 = 一個人的一生軌跡
    - 粒子可壓縮、可展開、可遞迴
    - 地球在，記憶就在
    """
    
    VERSION = "2.0.0"
    
    def __init__(self, base_path: str = "."):
        self.base = Path(base_path)
        self.particles_dir = self.base / "particles"
        self.snapshots_dir = self.base / "snapshots"
        self.exports_dir = self.base / "exports"
        
        # 初始化目錄
        for d in [self.particles_dir, self.snapshots_dir, self.exports_dir]:
            d.mkdir(exist_ok=True, parents=True)
        
        # 初始化組件
        self.compressor = AdvancedParticleCompressor()
        self.analyst = AnalystGuardian()
        self.kml_processor = KMLProcessor()
        
        # 載入或初始化粒子庫
        self.particles_file = self.particles_dir / "globe_particles.json"
        self.particles = self._load_particles()
    
    def _load_particles(self) -> List[Dict]:
        """載入粒子庫"""
        if self.particles_file.exists():
            return json.loads(self.particles_file.read_text(encoding="utf-8"))
        return []
    
    def _save_particles(self):
        """儲存粒子庫"""
        self.particles_file.write_text(
            json.dumps(self.particles, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
    
    # ==================== 核心功能 ====================
    
    def create_particle(
        self,
        content: str,
        latitude: float,
        longitude: float,
        altitude: float = 0,
        title: Optional[str] = None,
        source: str = "manual",
        extra_tags: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        創建新粒子
        
        Args:
            content: 內容（文字、描述等）
            latitude: 緯度
            longitude: 經度
            altitude: 海拔高度
            title: 標題（可選，自動生成）
            source: 來源（manual/screenshot/lidar/photo）
            extra_tags: 額外標籤
        
        Returns:
            新創建的粒子記錄
        """
        # 使用分析師守護者分析內容
        analysis = self.analyst.process(content)
        
        # 生成粒子 ID
        timestamp = datetime.now()
        particle_id = f"Earth.{safe_filename(title or 'particle')}.{timestamp.strftime('%Y%m%d%H%M%S')}"
        
        # 構建粒子
        particle = {
            "id": particle_id,
            "type": "memory",
            "body": "earth",
            "title": title or analysis["summary"][:50],
            "coords": {
                "lat": latitude,
                "lon": longitude,
                "alt": altitude
            },
            "time": timestamp.isoformat() + "Z",
            "content": content,
            "summary": analysis["summary"],
            "keywords": analysis["keywords"],
            "concepts": analysis["concepts"],
            "tags": list(set(["memory", source] + analysis["tags"] + (extra_tags or []))),
            "meta": {
                "content_type": analysis["content_type"],
                "language": analysis["language"],
                "sentiment": analysis["sentiment"],
                "source": source,
                "created_by": "ParticleGlobeMemorySystem",
                "version": self.VERSION
            }
        }
        
        # 粒子化壓縮（儲存壓縮版本）
        compressed = self.compressor.compress({
            "主體": particle["title"],
            "座標": particle["coords"],
            "時間": particle["time"],
            "內容": particle["content"],
            "標籤": particle["tags"]
        })
        particle["compressed"] = compressed
        
        # 加入粒子庫
        self.particles.append(particle)
        self._save_particles()
        
        print(f"✨ 新粒子已創建: {particle_id}")
        print(f"   📍 座標: {latitude}, {longitude}")
        print(f"   🏷️ 標籤: {', '.join(particle['tags'][:5])}")
        
        return particle
    
    def search_particles(
        self,
        keyword: Optional[str] = None,
        tag: Optional[str] = None,
        lat_range: Optional[Tuple[float, float]] = None,
        lon_range: Optional[Tuple[float, float]] = None,
        time_range: Optional[Tuple[str, str]] = None
    ) -> List[Dict]:
        """
        搜尋粒子
        
        Args:
            keyword: 關鍵詞搜尋
            tag: 標籤篩選
            lat_range: 緯度範圍 (min, max)
            lon_range: 經度範圍 (min, max)
            time_range: 時間範圍 (start, end)
        
        Returns:
            符合條件的粒子列表
        """
        results = []
        
        for p in self.particles:
            # 關鍵詞匹配
            if keyword:
                text = f"{p.get('title', '')} {p.get('content', '')} {p.get('summary', '')}"
                if keyword.lower() not in text.lower():
                    continue
            
            # 標籤匹配
            if tag and tag not in p.get("tags", []):
                continue
            
            # 座標範圍
            coords = p.get("coords", {})
            if lat_range:
                lat = coords.get("lat", 0)
                if not (lat_range[0] <= lat <= lat_range[1]):
                    continue
            if lon_range:
                lon = coords.get("lon", 0)
                if not (lon_range[0] <= lon <= lon_range[1]):
                    continue
            
            # 時間範圍
            if time_range:
                ptime = p.get("time", "")
                if not (time_range[0] <= ptime <= time_range[1]):
                    continue
            
            results.append(p)
        
        return results
    
    def export_to_kml(self, particles: Optional[List[Dict]] = None, output_name: str = "particle_globe") -> Path:
        """
        匯出為 KML 檔案（可用於 Google Earth）
        
        Args:
            particles: 要匯出的粒子列表（預設全部）
            output_name: 輸出檔案名稱
        
        Returns:
            匯出的檔案路徑
        """
        if particles is None:
            particles = self.particles
        
        kml_content = KMLProcessor.generate_kml(particles, f"粒子地球儀 - {output_name}")
        
        output_path = self.exports_dir / f"{output_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.kml"
        output_path.write_text(kml_content, encoding="utf-8")
        
        print(f"📤 已匯出 KML: {output_path}")
        print(f"   共 {len(particles)} 個粒子")
        
        return output_path
    
    def import_from_kml(self, kml_path: str) -> List[Dict]:
        """
        從 KML/KMZ 匯入粒子
        
        Args:
            kml_path: KML 或 KMZ 檔案路徑
        
        Returns:
            匯入的粒子列表
        """
        path = Path(kml_path)
        
        if path.suffix.lower() == ".kmz":
            kml_text = KMLProcessor.load_kml_from_kmz(path)
        else:
            kml_text = path.read_text(encoding="utf-8")
        
        nodes = KMLProcessor.parse_kml(kml_text, str(path))
        
        # 轉換為粒子格式並加入
        imported = []
        for node in nodes:
            particle = {
                "id": node["id"],
                "type": "import",
                "body": node["body"],
                "title": node["title"],
                "coords": node["coords"],
                "time": node.get("time") or datetime.now().isoformat() + "Z",
                "tags": node.get("tags", []) + ["imported"],
                "meta": node.get("meta", {})
            }
            self.particles.append(particle)
            imported.append(particle)
        
        self._save_particles()
        
        print(f"📥 已匯入 {len(imported)} 個粒子")
        
        return imported
    
    def snapshot(self, agent: str, state: Dict[str, Any]) -> Path:
        """
        記憶快照（事件驅動）
        
        Args:
            agent: 代理名稱
            state: 狀態資料
        
        Returns:
            快照檔案路徑
        """
        record = {
            "id": ulid(),
            "ts": datetime.utcnow().isoformat() + "Z",
            "agent": agent,
            "state": state
        }
        
        snapshots_file = self.snapshots_dir / "snapshots.jsonl"
        with snapshots_file.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
        
        print(f"📸 快照已儲存: {agent} @ {record['ts']}")
        
        return snapshots_file
    
    def get_statistics(self) -> Dict[str, Any]:
        """取得統計資訊"""
        tags_counter = Counter()
        for p in self.particles:
            tags_counter.update(p.get("tags", []))
        
        return {
            "total_particles": len(self.particles),
            "top_tags": tags_counter.most_common(10),
            "version": self.VERSION,
            "particles_file": str(self.particles_file)
        }
    
    def generate_report(self) -> str:
        """生成地球儀報告"""
        stats = self.get_statistics()
        
        report = f"""
# 🌍 粒子立體地球儀記憶報告

**生成時間**: {datetime.now().isoformat()}
**系統版本**: {self.VERSION}

## 📊 統計資訊

- **總粒子數**: {stats['total_particles']}
- **儲存位置**: {stats['particles_file']}

## 🏷️ 熱門標籤

"""
        for tag, count in stats['top_tags']:
            report += f"- **{tag}**: {count} 個粒子\n"
        
        report += """

## 💡 核心理念

- 怎麼過去，就怎麼回來
- 地球在，記憶就在
- 一顆地球儀 = 一個人的一生軌跡

---
*由 MrLiou 粒子立體地球儀記憶系統生成*
"""
        
        return report


# ============================================================================
# 主程式入口
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="🌍 MrLiou 粒子立體地球儀記憶系統",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
範例用法:
  # 創建新粒子
  python particle_globe_memory_system.py create --lat 24.98 --lon 121.24 --content "測試記憶"
  
  # 搜尋粒子
  python particle_globe_memory_system.py search --keyword "記憶"
  
  # 匯出 KML
  python particle_globe_memory_system.py export --output my_globe
  
  # 匯入 KML
  python particle_globe_memory_system.py import --file path/to/file.kml
  
  # 查看統計
  python particle_globe_memory_system.py stats
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", help="可用命令")
    
    # create 命令
    create_parser = subparsers.add_parser("create", help="創建新粒子")
    create_parser.add_argument("--lat", type=float, required=True, help="緯度")
    create_parser.add_argument("--lon", type=float, required=True, help="經度")
    create_parser.add_argument("--alt", type=float, default=0, help="海拔高度")
    create_parser.add_argument("--content", required=True, help="內容")
    create_parser.add_argument("--title", help="標題")
    create_parser.add_argument("--source", default="manual", help="來源")
    create_parser.add_argument("--tags", nargs="+", help="額外標籤")
    
    # search 命令
    search_parser = subparsers.add_parser("search", help="搜尋粒子")
    search_parser.add_argument("--keyword", help="關鍵詞")
    search_parser.add_argument("--tag", help="標籤")
    
    # export 命令
    export_parser = subparsers.add_parser("export", help="匯出 KML")
    export_parser.add_argument("--output", default="particle_globe", help="輸出名稱")
    
    # import 命令
    import_parser = subparsers.add_parser("import", help="匯入 KML/KMZ")
    import_parser.add_argument("--file", required=True, help="檔案路徑")
    
    # stats 命令
    subparsers.add_parser("stats", help="查看統計")
    
    # report 命令
    subparsers.add_parser("report", help="生成報告")
    
    args = parser.parse_args()
    
    # 初始化系統
    system = ParticleGlobeMemorySystem()
    
    if args.command == "create":
        system.create_particle(
            content=args.content,
            latitude=args.lat,
            longitude=args.lon,
            altitude=args.alt,
            title=args.title,
            source=args.source,
            extra_tags=args.tags
        )
    
    elif args.command == "search":
        results = system.search_particles(keyword=args.keyword, tag=args.tag)
        print(f"\n找到 {len(results)} 個粒子:\n")
        for p in results[:10]:
            print(f"  📍 {p['title']}")
            print(f"     座標: {p['coords']['lat']}, {p['coords']['lon']}")
            print(f"     標籤: {', '.join(p.get('tags', [])[:5])}")
            print()
    
    elif args.command == "export":
        system.export_to_kml(output_name=args.output)
    
    elif args.command == "import":
        system.import_from_kml(args.file)
    
    elif args.command == "stats":
        stats = system.get_statistics()
        print(f"\n🌍 粒子地球儀統計")
        print(f"   總粒子數: {stats['total_particles']}")
        print(f"   熱門標籤:")
        for tag, count in stats['top_tags'][:5]:
            print(f"     - {tag}: {count}")
    
    elif args.command == "report":
        report = system.generate_report()
        print(report)
    
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
