# 🤝 Particle Team MCP - AI 團隊協作系統

## 架構圖

```
                    ┌─────────────────────────────────┐
                    │         Team Coordinator         │
                    │      (任務分配 & 結果整合)        │
                    └───────────────┬─────────────────┘
                                    │
            ┌───────────┬───────────┼───────────┬───────────┐
            ▼           ▼           ▼           ▼           ▼
      ┌──────────┐┌──────────┐┌──────────┐┌──────────┐┌──────────┐
      │ 分析師   ││ 創意師   ││ 批判師   ││ 研究員   ││ 整合師   │
      │ Analyst  ││ Creator  ││ Critic   ││Researcher││Synthesizer│
      └──────────┘└──────────┘└──────────┘└──────────┘└──────────┘
           │           │           │           │           │
           │    平行處理 (Promise.allSettled)              │
           │           │           │           │           │
           └───────────┴───────────┴───────────┴───────────┘
                                    │
                                    ▼
                         ┌─────────────────────┐
                         │   整合結果 & 共識    │
                         └─────────────────────┘
```

## 🎭 AI 團隊成員

| Agent | 角色 | 專長 | 適用場景 |
|-------|------|------|----------|
| `analyst` | 分析師 | 結構化分析、邏輯推理 | 問題拆解、因果分析 |
| `creator` | 創意師 | 創意發想、設計思維 | 新功能設計、解決方案 |
| `critic` | 批判師 | 風險評估、邏輯驗證 | 程式碼審查、決策驗證 |
| `researcher` | 研究員 | 資料蒐集、知識整合 | 技術調研、文獻整理 |
| `synthesizer` | 整合師 | 觀點整合、共識建立 | 團隊決策、報告整合 |

## 🛠️ MCP Tools

### 1. team_dispatch - 分派任務

```json
{
  "name": "team_dispatch",
  "arguments": {
    "task": "分析粒子系統的記憶機制設計",
    "type": "analyze",
    "parallel": true
  }
}
```

**任務類型對應的團隊組合：**

| Type | Agents | 用途 |
|------|--------|------|
| `analyze` | 分析師 + 批判師 | 深度分析問題 |
| `create` | 創意師 + 分析師 | 設計新功能 |
| `review` | 批判師 + 分析師 + 整合師 | 審查與改進 |
| `research` | 研究員 + 分析師 | 調研與整理 |
| `synthesize` | 整合師 + 分析師 + 創意師 | 整合多方觀點 |
| `full_team` | 全員 | 重大決策 |

### 2. team_consensus - 團隊共識

```json
{
  "name": "team_consensus",
  "arguments": {
    "topic": "FlowAgent 是否應該支援多語言？",
    "rounds": 2
  }
}
```

讓團隊進行多輪討論，最後達成共識。

### 3. agent_direct - 直接對話

```json
{
  "name": "agent_direct",
  "arguments": {
    "agent_id": "analyst",
    "message": "幫我分析這段程式碼的效能問題"
  }
}
```

### 4. team_status - 查看狀態

```json
{
  "name": "team_status",
  "arguments": {
    "task_id": "task-xxx"
  }
}
```

## 📊 回應格式

```json
{
  "taskId": "task-1234567890-abc123",
  "type": "analyze",
  "parallel": true,
  "agentsUsed": [
    { "id": "analyst", "name": "分析師", "role": "Analyst" },
    { "id": "critic", "name": "批判師", "role": "Critic" }
  ],
  "results": [
    {
      "agent": "分析師",
      "response": "...",
      "duration": 1234
    },
    {
      "agent": "批判師",
      "response": "...",
      "duration": 1456
    }
  ],
  "synthesis": "整合後的結論...",
  "totalDuration": 1456
}
```

## 🚀 部署

```bash
# 1. 編譯
npx esbuild particle-team-mcp.ts --bundle --format=esm --outfile=worker.js

# 2. 設定 API Key
wrangler secret put ANTHROPIC_API_KEY

# 3. 部署
wrangler deploy
```

## 💡 使用場景

### 場景 1：程式碼審查
```
任務：審查 particle-chat Worker 的安全性
類型：review
團隊：批判師 + 分析師 + 整合師
```

### 場景 2：新功能設計
```
任務：設計 MemoryVault 的跨設備同步機制
類型：create
團隊：創意師 + 分析師
```

### 場景 3：技術決策
```
任務：選擇 KV vs D1 作為主要儲存
類型：full_team
團隊：全員參與
```

### 場景 4：深度調研
```
任務：調研 MCP 協議的最新發展
類型：research
團隊：研究員 + 分析師
```

## 🔗 端點

| 端點 | 用途 |
|------|------|
| `/health` | 健康檢查 + 團隊資訊 |
| `/mcp` | MCP HTTP 端點 |
| `/sse` | MCP SSE 端點 |
| `/dispatch` | 快速分派（非 MCP） |

---

**Mr.liou_夥伴 AI Team** - 團隊合作，效率加倍 🚀
