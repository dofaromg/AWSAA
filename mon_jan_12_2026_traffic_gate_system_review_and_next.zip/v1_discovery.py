from kubernetes import client, config

def discover_blocks() -> Dict[str, float]:
    """从 K8s namespace/labels 自动发现 blocks"""
    v1 = client.CoreV1Api()
    namespaces = v1.list_namespace()
    return {
        ns.metadata.name: get_quota(ns)
        for ns in namespaces.items
    }