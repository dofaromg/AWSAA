@app.post("/k8s/validate")
def k8s_validate(req: Dict):
    """ValidatingAdmissionWebhook handler"""
    obj = req["request"]["object"]
    old = req["request"]. get("oldObject")
    
    if obj["kind"] == "Deployment":
        current_replicas = old["spec"]["replicas"]
        new_replicas = obj["spec"]["replicas"]
        
        if new_replicas < current_replicas:
            # Scale-down 检查
            current_D = get_current_load_distribution()
            proposed_D = predict_load_after_scale(new_replicas)
            
            d = decide_scale_down(cfg, current_D, proposed_D, ...)
            
            return {
                "response": {
                    "uid": req["request"]["uid"],
                    "allowed": d.allow,
                    "status": {"message": d.reason}
                }
            }