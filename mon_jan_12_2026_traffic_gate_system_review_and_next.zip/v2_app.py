@app.post("/envoy/authz")
def envoy_authz(request: Request):
    """Envoy ext_authz 协议适配器"""
    headers = dict(request.headers)
    current_D = json.loads(headers.get("x-current-d", "{}"))
    # ... 解析 delta_D from request body
    d = decide_admission(...)
    
    if d.allow:
        return Response(status_code=200)  # OK
    else:
        return Response(
            status_code=403,
            headers={"x-reason": d.reason}
        )