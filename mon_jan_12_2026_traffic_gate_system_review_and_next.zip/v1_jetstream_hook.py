# 在 JetStream orchestrator 中集成
class TrafficGateInterceptor:
    def __init__(self, gate_url: str):
        self.gate_url = gate_url
        
    async def before_schedule(self, request):
        block = request.metadata.get("tenant_id")
        tokens = estimate_tokens(request)
        
        resp = await httpx.post(
            f"{self.gate_url}/gate/admission",
            json={
                "current_D": await self.get_current_load(),
                "delta_D": {block: tokens},
                "rho": await self.get_rho_proxy()
            }
        )
        
        if not resp.json()["allow"]:
            raise AdmissionDenied(resp.json()["reason"])