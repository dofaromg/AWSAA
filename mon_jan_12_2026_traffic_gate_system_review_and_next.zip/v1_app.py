from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

class ConfigReloader(FileSystemEventHandler):
    def on_modified(self, event):
        if event.src_path.endswith("config.yaml"):
            global cfg, BUDGETS
            CFG_RAW = load_config()
            cfg = GateConfig(...)  # 重新加载