def compute_rho_from_latency(p95_ms:  float, slo_ms: float) -> float:
    """将 p95 latency 映射到 0..1 congestion"""
    if p95_ms < slo_ms * 0.5:
        return 0.0
    elif p95_ms > slo_ms * 2.0:
        return 1.0
    else:
        # 线性插值
        return (p95_ms - slo_ms * 0.5) / (slo_ms * 1.5)